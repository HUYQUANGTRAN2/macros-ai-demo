# Hotwire Native implementation notes

Use this Rails app as the backend/web layer for the iOS app.

## Suggested iOS structure

- `UITabBarController`
  - Tab 1: Notes → `/notes`
  - Tab 2: Pinned → `/pinned`
  - Tab 3: Settings → `/settings`

Each tab should contain its own `UINavigationController` and Hotwire Native navigator.

## Native navigation demo flow

1. Open `/notes`
2. Tap a note card → `/notes/:id`
3. Tap Edit → `/notes/:id/edit`
4. Save → redirect back to detail page

## Modal demo flow

The Rails app already includes modal UI for:

- New note on `/notes`
- Delete confirmation on `/notes/:id`

In a full iOS shell, you can also map `/notes/new` to a native modal presentation if your Hotwire Native route/path configuration supports modal presentation.

## Minimum grading argument

This project is intentionally small. It shows a real mobile app backed by Rails while keeping the backend simple: one model, CRUD routes, tab-style screens, modal interactions, and detail/edit navigation.
