# Native Notes

A small Rails 8 + Hotwire Native-ready note-taking app built from the AppDev II capstone template.

## App concept

Native Notes is a simple mobile-first notes app. The Rails app provides CRUD pages for notes. The native iOS shell can use these routes inside Hotwire Native while presenting app-level navigation with a tab controller, navigation stacks, and modal flows.

## Core routes

- `/notes` — all notes list
- `/notes/:id` — note detail
- `/notes/:id/edit` — edit note
- `/pinned` — pinned notes tab
- `/settings` — settings tab

## Data model

`Note`

- `title:string`
- `body:text`
- `pinned:boolean`

## Native app requirement mapping

- Native navigation: Notes list → Note detail → Edit note
- Modals: New note modal and delete confirmation modal
- Tab controller: Notes / Pinned / Settings
- Small Rails backend: one model, one main controller, simple CRUD

## Setup

```bash
bundle install
bin/rails db:create db:migrate db:seed
bin/rails server
```
