Note.destroy_all

Note.create!(
  title: "AppDev II project direction",
  body: "Build a small Rails app that powers a real iOS note-taking app through Hotwire Native. Keep the scope focused: notes, pinned notes, settings, native navigation, and modals.",
  pinned: true
)

Note.create!(
  title: "Demo script",
  body: "Open Notes, create a note through the modal, open the detail page, edit it, pin it, then switch to the Pinned tab and Settings tab.",
  pinned: false
)

Note.create!(
  title: "Future polish",
  body: "Add tags, offline draft handling, native share sheet, and search suggestions after the MVP works.",
  pinned: false
)
