class PinnedController < ApplicationController
  def index
    @notes = Note.pinned
  end
end
