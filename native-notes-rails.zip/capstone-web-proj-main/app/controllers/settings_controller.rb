class SettingsController < ApplicationController
  def show
    @notes_count = Note.count
    @pinned_count = Note.pinned.count
  end
end
