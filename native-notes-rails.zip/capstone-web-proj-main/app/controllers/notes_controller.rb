class NotesController < ApplicationController
  before_action :set_note, only: %i[show edit update destroy toggle_pin]

  def index
    @query = params[:query].to_s.strip
    @notes = Note.recent
    @notes = @notes.where("title ILIKE :query OR body ILIKE :query", query: "%#{@query}%") if @query.present?
    @note = Note.new
  end

  def show
  end

  def new
    @note = Note.new
  end

  def edit
  end

  def create
    @note = Note.new(note_params)

    if @note.save
      redirect_to @note, notice: "Note created."
    else
      @notes = Note.recent
      render :index, status: :unprocessable_entity
    end
  end

  def update
    if @note.update(note_params)
      redirect_to @note, notice: "Note updated."
    else
      render :edit, status: :unprocessable_entity
    end
  end

  def destroy
    @note.destroy
    redirect_to notes_path, notice: "Note deleted."
  end

  def toggle_pin
    @note.update(pinned: !@note.pinned?)
    redirect_back fallback_location: @note
  end

  private

  def set_note
    @note = Note.find(params[:id])
  end

  def note_params
    params.require(:note).permit(:title, :body, :pinned)
  end
end
