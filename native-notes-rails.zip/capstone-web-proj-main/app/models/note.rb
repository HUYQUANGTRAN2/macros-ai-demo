class Note < ApplicationRecord
  validates :title, presence: true
  validates :body, presence: true

  scope :recent, -> { order(updated_at: :desc) }
  scope :pinned, -> { where(pinned: true).recent }

  def preview
    body.to_s.truncate(120)
  end
end
